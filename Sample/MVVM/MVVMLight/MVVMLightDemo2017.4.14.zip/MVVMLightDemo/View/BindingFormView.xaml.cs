﻿using System.Windows;
using System.Windows.Controls;

namespace MVVMLightDemo.View
{
    /// <summary>
    /// Interaction logic for BindingForm.xaml
    /// </summary>
    public partial class BindingFormView : Window
    {
        public BindingFormView()
        {
            InitializeComponent();
        }
    }
}