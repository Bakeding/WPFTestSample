﻿using System.Windows;

namespace MVVMLightDemo.View
{
    /// <summary>
    /// Interaction logic for BindBasic.xaml
    /// </summary>
    public partial class BindBasic : Window
    {
        public BindBasic()
        {
            InitializeComponent();
        }
    }
}
