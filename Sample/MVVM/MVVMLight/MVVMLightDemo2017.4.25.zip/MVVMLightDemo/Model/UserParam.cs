﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMLightDemo.Model
{
    public class UserParam
    {
        public String UserName { get; set; }

        public String UserPhone { get; set; }

        public String UserAdd { get; set; }

        public String UserSex { get; set; }
    }
}
