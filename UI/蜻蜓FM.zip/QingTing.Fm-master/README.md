#QingTing.Fm是调用[蜻蜓FM](https://www.qingting.fm/)API 查询界面内容，进行在线播放。  
# <h3>运行环境</h3>

* Visual Studio 2019，dotNet Framework 4.6.1 SDK
* 支持Windows Win7、8、10  

# <h4>[下载地址](https://github.com/yanjinhuagood/QingTing.Fm/releases/download/1.0.0/QingTing.FMexe.rar)</h4>
声明：本项目谥在学习，任何用于违法用途的行为与作者无关。<br/>
<h3>效果</h3>  
<img src="/resourcesImage/qingtingfm.gif"/>
